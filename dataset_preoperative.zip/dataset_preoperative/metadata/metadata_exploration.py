import os
import pandas as pd

csv_path = r"F:\A7 Learning\2025-2026\master-block1\Thesis_Hanah\dataset_preoperative\metadata\Metadata_table.csv"
df = pd.read_csv(csv_path)

print(df.shape)
print(df.head())

print(df.info())
print(df.describe(include="all"))